package com.wasel.delivery

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

private val Black = Color(0xFF080808)
private val Gold = Color(0xFFE7B84B)
private val Card = Color(0xFF171717)
private const val WHATSAPP_NUMBER = "249903774197"

data class DeliveryOrder(
    val id: Int,
    val customer: String,
    val phone: String,
    val pickup: String,
    val dropoff: String,
    val item: String,
    val notes: String,
    val price: String,
    val status: String = "طلب جديد"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Gold,
                    onPrimary = Black,
                    background = Black,
                    surface = Card,
                    onSurface = Color.White
                )
            ) {
                WaselApp()
            }
        }
    }
}

@Composable
fun WaselApp() {
    val context = LocalContext.current
    var adminMode by remember { mutableStateOf(false) }
    val orders = remember { mutableStateListOf<DeliveryOrder>() }
    var nextId by remember { mutableIntStateOf(1001) }

    Surface(modifier = Modifier.fillMaxSize(), color = Black) {
        Column(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxWidth().background(Black).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("واصل", color = Gold, fontSize = 36.sp, fontWeight = FontWeight.Black)
                Text("W A S E L", color = Gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("طلبك لحد بابك", color = Color.LightGray, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                Text("الخرطوم • أم درمان • بحري", color = Gold, fontSize = 13.sp)
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { adminMode = false },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = if (!adminMode) Gold else Card)
                ) { Text("طلب توصيل", color = if (!adminMode) Black else Color.White) }
                Button(
                    onClick = { adminMode = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = if (adminMode) Gold else Card)
                ) { Text("الإدارة", color = if (adminMode) Black else Color.White) }
            }

            if (adminMode) {
                AdminScreen(orders = orders, onWhatsApp = { order ->
                    val message = order.toArabicMessage()
                    openWhatsApp(context, message)
                }, onUpdateStatus = { order, status ->
                    val index = orders.indexOfFirst { it.id == order.id }
                    if (index >= 0) orders[index] = order.copy(status = status)
                })
            } else {
                OrderForm(
                    nextId = nextId,
                    onSubmit = { order ->
                        orders.add(order)
                        nextId += 1
                        openWhatsApp(context, "طلب جديد من تطبيق واصل\n${order.toArabicMessage()}")
                    },
                    onWhatsApp = { openWhatsApp(context, "السلام عليكم، أريد الاستفسار عن خدمة واصل.") }
                )
            }
        }
    }
}

@Composable
fun OrderForm(
    nextId: Int,
    onSubmit: (DeliveryOrder) -> Unit,
    onWhatsApp: () -> Unit
) {
    var customer by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var pickup by remember { mutableStateOf("") }
    var dropoff by remember { mutableStateOf("") }
    var item by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("اطلب توصيلك الآن", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("املأ البيانات وسننسّق معك لتأكيد الطلب والسعر.", color = Color.LightGray, fontSize = 13.sp)
        }
        item { WaselField("اسم العميل", customer, { customer = it }) }
        item { WaselField("رقم هاتف العميل", phone, { phone = it }, keyboard = KeyboardType.Phone) }
        item { WaselField("موقع الاستلام / العنوان", pickup, { pickup = it }) }
        item { WaselField("موقع التسليم / العنوان", dropoff, { dropoff = it }) }
        item { WaselField("نوع الطلب أو الغرض", item, { item = it }) }
        item { WaselField("ملاحظات إضافية (اختياري)", notes, { notes = it }, singleLine = false) }
        item { WaselField("سعر التوصيل (اتركه فارغاً إذا لم يُحدد)", price, { price = it }, keyboard = KeyboardType.Number) }
        item {
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF7777))
            if (submitted.isNotBlank()) Text(submitted, color = Gold, fontWeight = FontWeight.Bold)
            Button(
                onClick = {
                    if (customer.isBlank() || phone.isBlank() || pickup.isBlank() || dropoff.isBlank()) {
                        error = "يرجى تعبئة الاسم ورقم الهاتف وموقعي الاستلام والتسليم."
                    } else {
                        error = ""
                        val order = DeliveryOrder(
                            id = nextId,
                            customer = customer.trim(),
                            phone = phone.trim(),
                            pickup = pickup.trim(),
                            dropoff = dropoff.trim(),
                            item = item.trim().ifBlank { "غير محدد" },
                            notes = notes.trim().ifBlank { "لا توجد" },
                            price = price.trim().ifBlank { "يحدد لاحقاً" }
                        )
                        onSubmit(order)
                        submitted = "تم تجهيز الطلب رقم #${order.id} وإرسال التفاصيل إلى واتساب."
                        customer = ""; phone = ""; pickup = ""; dropoff = ""; item = ""; notes = ""; price = ""
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)
            ) { Text("إرسال طلب التوصيل", fontWeight = FontWeight.Bold) }
        }
        item {
            OutlinedButton(onClick = onWhatsApp, modifier = Modifier.fillMaxWidth()) {
                Text("تواصل مع واصل عبر واتساب", color = Gold)
            }
        }
        item {
            Text(
                "نسخة تجريبية: الطلبات محفوظة مؤقتاً داخل التطبيق المفتوح فقط، وليست مرتبطة بعد بقاعدة بيانات مشتركة.",
                color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun WaselField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    keyboard: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, color = Color.LightGray) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = singleLine,
        minLines = if (singleLine) 1 else 2,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Gold,
            unfocusedBorderColor = Color.DarkGray,
            focusedLabelColor = Gold,
            cursorColor = Gold,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
        )
    )
}

@Composable
fun AdminScreen(
    orders: List<DeliveryOrder>,
    onWhatsApp: (DeliveryOrder) -> Unit,
    onUpdateStatus: (DeliveryOrder, String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("لوحة إدارة واصل", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("عدد الطلبات في هذه الجلسة: ${orders.size}", color = Color.LightGray)
        if (orders.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لا توجد طلبات بعد. جرّب إرسال طلب من صفحة العميل.", color = Color.LightGray, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
                items(orders, key = { it.id }) { order ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Card),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("طلب #${order.id} • ${order.status}", color = Gold, fontWeight = FontWeight.Bold)
                            Text("العميل: ${order.customer}", color = Color.White)
                            Text("الهاتف: ${order.phone}", color = Color.White)
                            Text("استلام: ${order.pickup}", color = Color.LightGray)
                            Text("تسليم: ${order.dropoff}", color = Color.LightGray)
                            Text("الغرض: ${order.item}", color = Color.LightGray)
                            Text("السعر: ${order.price}", color = Gold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick = { onWhatsApp(order) }, modifier = Modifier.weight(1f)) {
                                    Text("واتساب", color = Gold)
                                }
                                Button(
                                    onClick = { onUpdateStatus(order, nextStatus(order.status)) },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)
                                ) { Text("تحديث الحالة") }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun nextStatus(current: String): String = when (current) {
    "طلب جديد" -> "تم التأكيد"
    "تم التأكيد" -> "قيد التوصيل"
    "قيد التوصيل" -> "تم التسليم"
    else -> "طلب جديد"
}

fun DeliveryOrder.toArabicMessage(): String =
    "رقم الطلب: #$id\nاسم العميل: $customer\nهاتف العميل: $phone\nموقع الاستلام: $pickup\nموقع التسليم: $dropoff\nالغرض: $item\nملاحظات: $notes\nسعر التوصيل: $price\nالحالة: $status"

fun openWhatsApp(context: android.content.Context, message: String) {
    val encoded = URLEncoder.encode(message, StandardCharsets.UTF_8.toString())
    val uri = Uri.parse("https://wa.me/$WHATSAPP_NUMBER?text=$encoded")
    val intent = Intent(Intent.ACTION_VIEW, uri)
    try {
        context.startActivity(intent)
    } catch (_: Exception) {
        val fallback = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$WHATSAPP_NUMBER"))
        context.startActivity(fallback)
    }
}
